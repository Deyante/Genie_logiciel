package view;

import view.CalculatorGUI;
import javafx.application.Application;

public class main {

	public static void main(String[] args) {
		Application.launch(CalculatorGUI.class, args); //On lance l'affichage de la calculatrice
	}
}

